# Evidências visuais

Esta pasta está reservada para capturas reais do navegador após a publicação no GitHub Pages:

- visão geral da dashboard;
- exemplo com filtros aplicados (modelo `911 Turbo S` e pagamento `Wire Transfer`).

As capturas ainda não foram incluídas porque a publicação no GitHub Pages depende da conexão da conta GitHub e da validação do deploy. Nenhuma imagem ilustrativa ou simulada é apresentada como evidência de execução.
